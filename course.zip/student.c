/**
 * @file student.c
 * @author Alex McMullen 
 * @brief 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief takes in a student and a grade, and adds a student's grade to an array
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); //base case, if the number of grades is 1, then create array which holds one grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); // reallocate student->grades so that it can hold another grade
  }
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief takes in a student, and calculates the average grade of the students
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; // base case, if there are no students, return 0

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; //add up all of the grades of each student
  return total / ((double) student->num_grades); //return average
}
/**
 * @brief takes in a student and prints each of its items, including the name, ID, grades, and average grade of each student
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) //iterate through student->grades and print each of its elements
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief takes in a number of grades and returns a new student 
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); //create pointer to new_student which holds one student

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); //give the student a random ID
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) //create random grades for the student
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}