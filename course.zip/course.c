/**
 * @file course.c
 * @author Alex McMullen 
 * @brief 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 /**
  * @brief takes in a course and a student, adds 1 to total student counter and adds student to students array.
  * 
  * @param course 
  * @param student 
  */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); //base case, if there is one student in the class, make course->student have a size of one student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //every time a new student gets added, course->student is reallocated so that it can hold another student
  }
  course->students[course->total_students - 1] = *student;
} 
/**
 * @brief takes in a course and prints all items of the course, including name, code, and total students
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //loop to print all elements of course->student
    print_student(&course->students[i]);
}
/**
 * @brief takes in a course and returns a pointer to the student with the highest average
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //base case, return nothing if class has no students
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) //iterate through course->total students and find the student with the highest average, then stores them as the variable student
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief takes in a course and a pointer to the total number of students passing, then returns the students who have an average greater than 50
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) //iterates through course->total_students and adds 1 to count each time a student is passing
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //creates empty array that has the size of the number of students passing

  int j = 0;
  for (int i = 0; i < course->total_students; i++) //puts the students who are passing into the passing array
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}