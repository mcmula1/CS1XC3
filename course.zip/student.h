 /**
 * @file course.h
 * @author Alex McMullen 
 * @brief 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

 /**
  * @brief creates student type that has char arrays of first name and last name, each having a max size of 50, a char id, which has a max size of 11, a pointer to grades, and a number of grades
  * 
  */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
