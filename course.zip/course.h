/**
 * @file course.h
 * @author Alex McMullen 
 * @brief 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 /**
  * @brief creates course type that has a char array called name, with max size of 100, a char array called code, with max size of 10, student names, and a total number of students
  * 
  */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


